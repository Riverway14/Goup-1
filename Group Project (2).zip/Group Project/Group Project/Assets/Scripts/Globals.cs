﻿using UnityEngine;

public class Globals : MonoBehaviour
{


    void Start()
    {
        
    }

    void Update()
    {
        
    }
}